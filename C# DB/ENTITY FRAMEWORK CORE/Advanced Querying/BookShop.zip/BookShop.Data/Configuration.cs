﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=DESKTOP-NNIGS3T\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
