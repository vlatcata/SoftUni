﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-NNIGS3T\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
