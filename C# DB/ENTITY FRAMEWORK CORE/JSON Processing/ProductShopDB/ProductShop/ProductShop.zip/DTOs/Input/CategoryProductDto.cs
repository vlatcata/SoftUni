﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTOs.Input
{
    public class CategoryProductDto
    {
        public int CategoryId { get; set; }

        public int ProductId { get; set; }
    }
}
