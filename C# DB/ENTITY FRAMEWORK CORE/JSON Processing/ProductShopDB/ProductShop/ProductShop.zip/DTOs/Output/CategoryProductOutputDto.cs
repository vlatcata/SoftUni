﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTOs.Output
{
    public class CategoryProductOutputDto
    {
    }
}
