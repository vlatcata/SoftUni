﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-NNIGS3T\SQLEXPRESS;Database=MusicHub;Integrated Security=True";
    }
}
