﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=DESKTOP-NNIGS3T\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}