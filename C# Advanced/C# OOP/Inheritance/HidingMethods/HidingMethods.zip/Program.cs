﻿using System;

namespace HidingMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();
            student.Work();
        }
    }
}
