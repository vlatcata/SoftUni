﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HidingMethods
{
    class Person
    {
        public void Work()
        {
            Console.WriteLine("I am working");
        }

        public string Name { get; set; }
    }
}
