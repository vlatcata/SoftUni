﻿using System;

namespace ConstructorInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            FrontEndProgrammer frontEnd = new FrontEndProgrammer("Bai Ti Pesho", 200);
        }
    }
}
