﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    class CrossMotorcycle : Motorcycle
    {
        public CrossMotorcycle(int horsepower, double fuel) : base(horsepower, fuel)
        {
        }
    }
}
