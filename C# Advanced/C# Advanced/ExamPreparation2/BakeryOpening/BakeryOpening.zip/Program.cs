﻿using System;

namespace BakeryOpenning
{
    
    public class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}
