﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generics_Exercise
{
   public class Box<T>
    {
        public Box()
        {
            Value = new List<T>;
        }

        public List<T> Value { get; set; }



        public static void Swap<T>(List<T>, int firstIndex, int secondIndex)
        {
           
        }
    }
}
