﻿namespace FootballManager.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString = @"Server=DESKTOP-NNIGS3T\SQLEXPRESS;Database=FootballManager;Integrated Security=True;";
    }
}
